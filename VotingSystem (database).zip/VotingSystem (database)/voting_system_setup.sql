-- ============================================================
--  voting_system database setup for XAMPP / phpMyAdmin
--  Run this entire script in phpMyAdmin's SQL tab
-- ============================================================

CREATE DATABASE IF NOT EXISTS voting_system
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE voting_system;

-- ----------------------------------------------------------
-- 1. VOTERS table
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS voters (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    full_name  VARCHAR(100) NOT NULL,
    voter_id   VARCHAR(50)  NOT NULL UNIQUE,
    username   VARCHAR(100) NOT NULL,
    password   VARCHAR(100) NOT NULL,
    age        INT          NOT NULL DEFAULT 0,
    sex        VARCHAR(10)  DEFAULT '',
    created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------
-- 2. CANDIDATES table
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS candidates (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    position VARCHAR(50)  NOT NULL,
    name     VARCHAR(100) NOT NULL,
    votes    INT          NOT NULL DEFAULT 0,
    UNIQUE KEY uq_candidate (position, name)
);

-- ----------------------------------------------------------
-- 3. VOTES table  (tracks who has already voted)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS votes (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    voter_name      VARCHAR(100) NOT NULL,
    president_vote  VARCHAR(100) NOT NULL,
    vp_vote         VARCHAR(100) NOT NULL,
    secretary_vote  VARCHAR(100) NOT NULL,
    treasurer_vote  VARCHAR(100) NOT NULL,
    voted_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------
-- 4. Seed data  (matches original ElectionData.java defaults)
-- ----------------------------------------------------------

-- Sample voter (same as original hardcoded entry)
INSERT IGNORE INTO voters (full_name, voter_id, username, password, age, sex)
VALUES ('Sample User', '2026-0001', 'Sample User', '1234', 18, 'Male');

-- Default candidates
INSERT IGNORE INTO candidates (position, name, votes) VALUES
    ('President',      'Alice',  0),
    ('President',      'Bob',    0),
    ('Vice President', 'Carol',  0),
    ('Vice President', 'David',  0),
    ('Secretary',      'Emma',   0),
    ('Secretary',      'Frank',  0),
    ('Treasurer',      'Grace',  0),
    ('Treasurer',      'Henry',  0);
